# 🛡️ FakeShield — Fake News Detection System

> An end-to-end Machine Learning & Deep Learning pipeline for detecting fake news,
> with a premium Streamlit dashboard for interactive analysis.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Project Structure](#project-structure)
- [Setup](#setup)
- [Dataset](#dataset)
- [Running the Pipeline](#running-the-pipeline)
- [Launching the Dashboard](#launching-the-dashboard)
- [Model Performance](#model-performance)
- [Example Input / Output](#example-inputoutput)
- [Architecture Details](#architecture-details)

---

## Overview

FakeShield combines classical NLP (TF-IDF) with modern neural architectures (Bidirectional LSTM, ANN)
to classify news articles as **Real** or **Fake**. All models are evaluated with accuracy, precision,
recall, and F1-score. A fully-featured Streamlit dashboard enables single-article and batch prediction.

### Key Features

| Feature | Details |
|---|---|
| ML Models | Logistic Regression, Naive Bayes, SVM (calibrated), Random Forest |
| DL Models | Bidirectional LSTM, Lightweight ANN |
| Text Pipeline | URL/HTML removal → stopword removal → lemmatization (WordNetLemmatizer) |
| Features | TF-IDF (5 000 features, bigrams) + Keras padded sequences |
| Dashboard | 4-tab Streamlit UI with dark theme, confidence gauge, batch upload |
| Output | Label (Real/Fake) + confidence %, confusion matrix, training curves |

---

## Project Structure

```
fake-news-detection/
├── data/
│   ├── raw/                  ← place Fake.csv + True.csv here
│   └── processed/            ← auto-generated cleaned CSVs
├── models/                   ← saved .pkl / .h5 / confusion matrix PNGs
├── src/
│   ├── data_loader.py        ← load & split dataset
│   ├── preprocess.py         ← text cleaning / lemmatization
│   ├── features.py           ← TF-IDF & Keras tokenizer
│   ├── train_ml_models.py    ← train & evaluate ML models
│   ├── train_dl_model.py     ← train LSTM / ANN with Keras
│   ├── evaluate.py           ← shared metrics & plotting
│   └── predict.py            ← inference function & CLI
├── app.py                    ← Streamlit dashboard
├── requirements.txt
└── README.md
```

---

## Setup

### 1. Clone / download the project

```bash
cd "Fake News Detection System"
```

### 2. Create a virtual environment (recommended)

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS / Linux
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Download NLTK data

```python
import nltk
nltk.download('punkt')
nltk.download('punkt_tab')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('omw-1.4')
```

> **Note**: The preprocessing script downloads these automatically on first run.

---

## Dataset

This project uses the **Fake and Real News Dataset** from Kaggle:

🔗 https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset

Download and place the two CSV files inside `data/raw/`:

```
data/raw/Fake.csv
data/raw/True.csv
```

The dataset contains ~44 000 articles:
- `Fake.csv` — ~23 000 fake news articles
- `True.csv` — ~21 000 real news articles

Each has columns: `title`, `text`, `subject`, `date`

---

## Running the Pipeline

Run **each script in order** from the project root:

### Step 1 — Load & split data

```bash
python src/data_loader.py
```

Outputs:
- `data/processed/train.csv`
- `data/processed/test.csv`

### Step 2 — Clean & preprocess

```bash
python src/preprocess.py
```

Outputs:
- `data/processed/train_clean.csv`
- `data/processed/test_clean.csv`

### Step 3 — Build feature extractors (optional standalone)

```bash
python src/features.py
```

Outputs:
- `models/tfidf_vectorizer.pkl`
- `models/keras_tokenizer.pkl`

### Step 4 — Train ML models

```bash
python src/train_ml_models.py
```

Outputs:
- `models/logistic_regression.pkl`
- `models/naive_bayes.pkl`
- `models/svm.pkl`
- `models/random_forest.pkl`
- `models/ml_metrics.json`
- `models/cm_*.png` (confusion matrix images)

### Step 5 — Train DL model

```bash
# Bidirectional LSTM (recommended)
python src/train_dl_model.py --arch lstm

# Lightweight ANN (faster training)
python src/train_dl_model.py --arch ann
```

Outputs:
- `models/lstm_model.h5` (or `ann_model.h5`)
- `models/dl_training_curves.png`
- `models/dl_metrics.json`

---

## Launching the Dashboard

```bash
streamlit run app.py
```

The dashboard opens at **http://localhost:8501**

### Dashboard Tabs

| Tab | Description |
|---|---|
| 🔍 Predict | Paste article text, select model, get Real/Fake result + confidence |
| 📈 Model Comparison | Table + bar chart of all models across 4 metrics |
| 🔲 Confusion Matrix | Per-model heatmap |
| ℹ️ About | Pipeline overview & architecture details |

---

## Model Performance

> Results on the held-out 20% test set (typical for this dataset):

| Model | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Logistic Regression | ~0.987 | ~0.988 | ~0.987 | ~0.987 |
| SVM | ~0.989 | ~0.990 | ~0.988 | ~0.989 |
| Random Forest | ~0.982 | ~0.983 | ~0.981 | ~0.982 |
| Naive Bayes | ~0.942 | ~0.945 | ~0.942 | ~0.943 |
| LSTM | ~0.991 | ~0.992 | ~0.990 | ~0.991 |

> ⚠️ Actual numbers depend on your dataset version and random seed.

---

## Example Input / Output

**Input:**
```
NASA scientists have confirmed the existence of a second Earth in a nearby solar system.
The planet, dubbed "Kepler-452b", has similar atmospheric conditions to Earth.
```

**Output (Logistic Regression):**
```
🟢 Real  —  Confidence: 84.3%
```

**Input:**
```
BREAKING: Government secretly adding mind-control chemicals to tap water!
Anonymous insider reveals shocking truth hidden from public for decades.
```

**Output (SVM):**
```
🔴 Fake  —  Confidence: 97.6%
```

---

## Architecture Details

### Text Preprocessing (`preprocess.py`)

1. Lowercase conversion
2. URL removal (`https?://...`)
3. HTML tag stripping
4. Punctuation / number / special character removal
5. Tokenisation (`nltk.word_tokenize`)
6. Stopword removal (NLTK English)
7. **Lemmatization** (`WordNetLemmatizer`) ← default
   - Alternative: **Stemming** (`PorterStemmer`) — set `use_stemming=True`

### LSTM Architecture

```
Input (300 tokens)
  └─ Embedding(vocab=10000, dim=64)
       └─ Bidirectional LSTM(64)
            └─ Dropout(0.4)
                 └─ Dense(32, relu)
                      └─ Dropout(0.3)
                           └─ Dense(1, sigmoid)
```

- **Loss**: Binary Cross-Entropy
- **Optimizer**: Adam (lr=0.001)
- **Callbacks**: EarlyStopping (patience=3), ModelCheckpoint

### ANN Architecture (lighter)

```
Input (300 tokens)
  └─ Embedding(vocab=10000, dim=64)
       └─ GlobalAveragePooling1D
            └─ Dense(64, relu) → Dropout(0.3)
                 └─ Dense(32, relu)
                      └─ Dense(1, sigmoid)
```

---

## CLI Prediction

```bash
python src/predict.py "Scientists discover new vaccine for rare disease" --model "Logistic Regression"
# → 🟢 Real  —  confidence: 89.20%
```

---

## License

MIT — free to use, modify, and distribute.
