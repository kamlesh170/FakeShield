"""
app.py  —  Fake News Detection System  ·  Streamlit Dashboard
=============================================================
Launch:
    streamlit run app.py
"""

# ── std-lib ────────────────────────────────────────────────────────────────
import os
import sys
import json
import io
import logging

# ── third-party ────────────────────────────────────────────────────────────
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import streamlit as st

# ── local modules (on sys.path) ─────────────────────────────────────────────
PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
SRC_DIR = os.path.join(PROJECT_ROOT, "src")
sys.path.insert(0, SRC_DIR)

logging.basicConfig(level=logging.WARNING)

# ---------------------------------------------------------------------------
# Page config  (must be first Streamlit call)
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="FakeShield · Fake News Detector",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Custom CSS
# ---------------------------------------------------------------------------
st.markdown(
    """
<style>
/* ── Google Font ── */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@400;600;700;800&display=swap');

/* ── Global ── */
html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* ── App background ── */
.stApp {
    background: linear-gradient(135deg, #0d1117 0%, #161b27 50%, #0d1117 100%);
    color: #e2e8f0;
}

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #1a2233 0%, #111827 100%);
    border-right: 1px solid rgba(99,102,241,0.25);
}
[data-testid="stSidebar"] * { color: #c7d2e7 !important; }

/* ── Hero banner ── */
.hero-banner {
    background: linear-gradient(135deg, #1e1b4b 0%, #312e81 40%, #4338ca 100%);
    border-radius: 20px;
    padding: 2.5rem 3rem;
    margin-bottom: 2rem;
    border: 1px solid rgba(99,102,241,0.4);
    box-shadow: 0 8px 40px rgba(67,56,202,0.35);
}
.hero-title {
    font-family: 'Outfit', sans-serif;
    font-size: 2.8rem;
    font-weight: 800;
    background: linear-gradient(90deg, #a5b4fc, #e0e7ff, #c7d2fe);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin: 0 0 0.4rem 0;
    line-height: 1.15;
}
.hero-sub {
    color: #a5b4fc;
    font-size: 1.05rem;
    font-weight: 400;
    margin: 0;
}

/* ── Section card ── */
.card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(99,102,241,0.2);
    border-radius: 16px;
    padding: 1.8rem 2rem;
    margin-bottom: 1.5rem;
    backdrop-filter: blur(8px);
}
.card-title {
    font-family: 'Outfit', sans-serif;
    font-size: 1.15rem;
    font-weight: 700;
    color: #a5b4fc;
    margin-bottom: 1rem;
    letter-spacing: 0.03em;
}

/* ── Result badges ── */
.result-real {
    background: linear-gradient(135deg, #064e3b, #065f46);
    border: 2px solid #10b981;
    border-radius: 16px;
    padding: 1.6rem 2rem;
    text-align: center;
    box-shadow: 0 0 30px rgba(16,185,129,0.2);
}
.result-fake {
    background: linear-gradient(135deg, #7f1d1d, #991b1b);
    border: 2px solid #ef4444;
    border-radius: 16px;
    padding: 1.6rem 2rem;
    text-align: center;
    box-shadow: 0 0 30px rgba(239,68,68,0.2);
}
.result-label {
    font-family: 'Outfit', sans-serif;
    font-size: 2.2rem;
    font-weight: 800;
    margin: 0.2rem 0;
}
.result-conf {
    font-size: 1rem;
    opacity: 0.85;
    margin-top: 0.4rem;
}

/* ── Metric tiles ── */
.metric-tile {
    background: rgba(99,102,241,0.1);
    border: 1px solid rgba(99,102,241,0.25);
    border-radius: 12px;
    padding: 1rem 1.2rem;
    text-align: center;
}
.metric-val {
    font-family: 'Outfit', sans-serif;
    font-size: 1.7rem;
    font-weight: 700;
    color: #a5b4fc;
}
.metric-name {
    font-size: 0.78rem;
    color: #94a3b8;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-top: 0.2rem;
}

/* ── Tabs ── */
[data-baseweb="tab-list"] {
    background: rgba(30,27,75,0.6) !important;
    border-radius: 12px;
    padding: 0.3rem;
    gap: 0.3rem;
}
[data-baseweb="tab"] {
    border-radius: 9px !important;
    color: #94a3b8 !important;
    font-weight: 500;
}
[aria-selected="true"][data-baseweb="tab"] {
    background: linear-gradient(135deg, #4338ca, #6366f1) !important;
    color: #fff !important;
}

/* ── Buttons ── */
.stButton > button {
    background: linear-gradient(135deg, #4338ca, #6366f1);
    color: #fff;
    border: none;
    border-radius: 10px;
    font-family: 'Outfit', sans-serif;
    font-weight: 600;
    font-size: 1rem;
    padding: 0.6rem 2rem;
    transition: all 0.2s ease;
    box-shadow: 0 4px 15px rgba(99,102,241,0.4);
    width: 100%;
}
.stButton > button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 25px rgba(99,102,241,0.55);
    background: linear-gradient(135deg, #3730a3, #4f46e5);
}

/* ── Select / text area ── */
.stSelectbox > div > div,
.stTextArea textarea {
    background: rgba(15,20,40,0.7) !important;
    border: 1px solid rgba(99,102,241,0.35) !important;
    border-radius: 10px !important;
    color: #e2e8f0 !important;
}
.stTextArea textarea:focus {
    border-color: #6366f1 !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,0.2) !important;
}

/* ── Progress bar ── */
[data-testid="stProgress"] > div > div > div {
    background: linear-gradient(90deg, #4338ca, #10b981) !important;
    border-radius: 4px;
}

/* ── Dataframe ── */
.stDataFrame { border-radius: 12px; overflow: hidden; }

/* ── Info / success / error banners ── */
.stAlert { border-radius: 12px; }

/* ── Divider ── */
hr { border-color: rgba(99,102,241,0.2); }
</style>
""",
    unsafe_allow_html=True,
)


# ===========================================================================
# Constants
# ===========================================================================
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")

ML_MODELS = ["Logistic Regression", "Naive Bayes", "SVM", "Random Forest"]
DL_MODELS = ["LSTM", "ANN"]
ALL_MODELS = ML_MODELS + DL_MODELS

MODEL_ICONS = {
    "Logistic Regression": "📊",
    "Naive Bayes": "📐",
    "SVM": "⚡",
    "Random Forest": "🌲",
    "LSTM": "🧠",
    "ANN": "🔬",
}


# ===========================================================================
# Cached resource loaders
# ===========================================================================

@st.cache_resource(show_spinner="Loading TF-IDF vectorizer …")
def _get_tfidf():
    from features import load_tfidf
    return load_tfidf()


@st.cache_resource(show_spinner="Loading Keras tokenizer …")
def _get_keras_tokenizer():
    from features import load_keras_tokenizer
    return load_keras_tokenizer()


@st.cache_resource(show_spinner="Loading ML model …")
def _get_ml_model(model_name: str):
    from train_ml_models import load_model
    return load_model(model_name)


@st.cache_resource(show_spinner="Loading deep learning model …")
def _get_dl_model(arch: str):
    from train_dl_model import load_dl_model
    return load_dl_model(arch)


@st.cache_data(show_spinner=False)
def load_metrics_df() -> pd.DataFrame:
    """Load combined ML + DL metrics into a single DataFrame."""
    rows = []

    ml_path = os.path.join(MODELS_DIR, "ml_metrics.json")
    if os.path.exists(ml_path):
        with open(ml_path) as f:
            rows.extend(json.load(f))

    dl_path = os.path.join(MODELS_DIR, "dl_metrics.json")
    if os.path.exists(dl_path):
        with open(dl_path) as f:
            dl = json.load(f)
            rows.append({
                "model": dl.get("model", "LSTM"),
                "accuracy": dl.get("accuracy", 0),
                "precision": dl.get("precision", 0),
                "recall": dl.get("recall", 0),
                "f1": dl.get("f1", 0),
            })

    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).sort_values("f1", ascending=False).reset_index(drop=True)


@st.cache_data(show_spinner=False)
def load_dataset_info() -> dict:
    """Load basic info from processed CSVs for the sidebar."""
    info = {"train_size": "N/A", "test_size": "N/A", "fake": "N/A", "real": "N/A"}
    try:
        train_path = os.path.join(PROCESSED_DIR, "train_clean.csv")
        test_path = os.path.join(PROCESSED_DIR, "test_clean.csv")
        if os.path.exists(train_path) and os.path.exists(test_path):
            train = pd.read_csv(train_path)
            test = pd.read_csv(test_path)
            combined = pd.concat([train, test])
            info["train_size"] = f"{len(train):,}"
            info["test_size"] = f"{len(test):,}"
            info["fake"] = f"{(combined['label'] == 0).sum():,}"
            info["real"] = f"{(combined['label'] == 1).sum():,}"
    except Exception:
        pass
    return info


# ===========================================================================
# Prediction helper (uses cached artefacts)
# ===========================================================================

def run_prediction(text: str, model_choice: str) -> dict:
    """
    Run prediction by directly calling cached models — avoids re-loading files
    on every call (unlike predict.py which always reads from disk).
    """
    from preprocess import clean_text
    from features import transform_tfidf, texts_to_sequences, KERAS_MAX_LEN

    cleaned = clean_text(text)
    if not cleaned.strip():
        raise ValueError("Text is empty after cleaning. Please provide more content.")

    if model_choice in ML_MODELS:
        vectorizer = _get_tfidf()
        model = _get_ml_model(model_choice)
        X = transform_tfidf(vectorizer, [cleaned])
        y_pred = int(model.predict(X)[0])
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(X)[0]
            confidence = float(probs[y_pred])
        else:
            confidence = 1.0
    else:
        arch = model_choice.lower()
        tokenizer = _get_keras_tokenizer()
        model = _get_dl_model(arch)
        X = texts_to_sequences(tokenizer, [cleaned], max_len=KERAS_MAX_LEN)
        prob = float(model.predict(X, verbose=0).ravel()[0])
        if prob >= 0.5:
            y_pred, confidence = 1, prob
        else:
            y_pred, confidence = 0, 1.0 - prob

    label = "Real" if y_pred == 1 else "Fake"
    return {"label": label, "confidence": confidence, "model_choice": model_choice}


# ===========================================================================
# Chart helpers
# ===========================================================================

def make_comparison_bar(df: pd.DataFrame) -> plt.Figure:
    """Dark-theme grouped bar chart for model comparison."""
    metrics = ["accuracy", "precision", "recall", "f1"]
    colors = ["#6366f1", "#10b981", "#f59e0b", "#ef4444"]
    models = df["model"].tolist()
    x = np.arange(len(models))
    bar_w = 0.18

    fig, ax = plt.subplots(figsize=(max(10, len(models) * 2.2), 5))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#161b27")

    for i, (m, c) in enumerate(zip(metrics, colors)):
        offset = (i - 1.5) * bar_w
        bars = ax.bar(x + offset, df[m].values, width=bar_w, label=m.capitalize(),
                      color=c, alpha=0.88, linewidth=0)
        for bar in bars:
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.008,
                    f"{bar.get_height():.3f}",
                    ha="center", va="bottom", fontsize=7.5, color="#e2e8f0")

    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=15, ha="right", fontsize=10, color="#e2e8f0")
    ax.set_ylim(0, 1.15)
    ax.set_ylabel("Score", color="#94a3b8", fontsize=11)
    ax.set_title("Model Comparison — All Metrics", color="#e2e8f0",
                 fontsize=13, fontweight="bold", pad=14)
    ax.tick_params(colors="#94a3b8")
    for spine in ax.spines.values():
        spine.set_edgecolor("rgba(99,102,241,0.3)")
    ax.grid(axis="y", linestyle="--", alpha=0.25, color="#6366f1")
    legend = ax.legend(loc="upper right", fontsize=9,
                       facecolor="#1e1b4b", edgecolor="#6366f1", labelcolor="#e2e8f0")
    fig.tight_layout()
    return fig


def make_cm_plot(model_name: str) -> plt.Figure | None:
    """Load a saved confusion-matrix PNG or return None."""
    name_map = {
        "Logistic Regression": "cm_logistic_regression.png",
        "Naive Bayes":         "cm_naive_bayes.png",
        "SVM":                 "cm_svm.png",
        "Random Forest":       "cm_random_forest.png",
        "LSTM":                "cm_lstm.png",
        "ANN":                 "cm_ann.png",
    }
    fname = name_map.get(model_name)
    if fname is None:
        return None
    path = os.path.join(MODELS_DIR, fname)
    if not os.path.exists(path):
        return None

    from PIL import Image
    fig, ax = plt.subplots(figsize=(6, 5))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#0d1117")
    img = Image.open(path)
    ax.imshow(img)
    ax.axis("off")
    fig.tight_layout(pad=0)
    return fig


def make_training_curves_fig() -> plt.Figure | None:
    """Load the saved DL training curves PNG."""
    path = os.path.join(MODELS_DIR, "dl_training_curves.png")
    if not os.path.exists(path):
        return None
    from PIL import Image
    fig, ax = plt.subplots(figsize=(12, 4))
    fig.patch.set_facecolor("#0d1117")
    ax.set_facecolor("#0d1117")
    img = Image.open(path)
    ax.imshow(img)
    ax.axis("off")
    fig.tight_layout(pad=0)
    return fig


# ===========================================================================
# Sidebar
# ===========================================================================

def render_sidebar():
    with st.sidebar:
        st.markdown(
            """
            <div style='text-align:center; padding: 1rem 0 0.5rem;'>
                <span style='font-size:3rem;'>🛡️</span>
                <h2 style='font-family:Outfit,sans-serif; font-size:1.5rem;
                           font-weight:800; color:#a5b4fc; margin:0.2rem 0 0;'>
                    FakeShield
                </h2>
                <p style='color:#64748b; font-size:0.8rem; margin:0;'>
                    Fake News Detection System
                </p>
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.divider()

        # ── Dataset info ──
        st.markdown("### 📂 Dataset Info")
        info = load_dataset_info()
        for label, val in [
            ("🚂 Train samples", info["train_size"]),
            ("🧪 Test samples", info["test_size"]),
            ("🔴 Fake articles", info["fake"]),
            ("🟢 Real articles", info["real"]),
        ]:
            st.markdown(
                f"<div style='display:flex;justify-content:space-between;"
                f"padding:0.3rem 0;border-bottom:1px solid rgba(99,102,241,0.12);'>"
                f"<span style='color:#94a3b8;font-size:0.85rem;'>{label}</span>"
                f"<span style='color:#a5b4fc;font-weight:600;font-size:0.85rem;'>{val}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )

        st.divider()

        # ── How-to ──
        st.markdown("### 📋 How to Use")
        st.markdown(
            """
            <ol style='color:#94a3b8;font-size:0.85rem;padding-left:1.2rem;line-height:1.8;'>
                <li>Paste a news headline or article body in the <b style='color:#a5b4fc;'>Predict</b> tab</li>
                <li>Select a model from the dropdown</li>
                <li>Click <b style='color:#a5b4fc;'>Analyse Article</b></li>
                <li>Review the prediction, confidence, and detailed analysis</li>
            </ol>
            """,
            unsafe_allow_html=True,
        )

        st.divider()

        # ── Setup status ──
        st.markdown("### ⚙️ System Status")
        checks = {
            "TF-IDF vectorizer": os.path.exists(
                os.path.join(MODELS_DIR, "tfidf_vectorizer.pkl")),
            "Keras tokenizer":   os.path.exists(
                os.path.join(MODELS_DIR, "keras_tokenizer.pkl")),
            "Logistic Regression": os.path.exists(
                os.path.join(MODELS_DIR, "logistic_regression.pkl")),
            "Naive Bayes":       os.path.exists(
                os.path.join(MODELS_DIR, "naive_bayes.pkl")),
            "SVM":               os.path.exists(
                os.path.join(MODELS_DIR, "svm.pkl")),
            "Random Forest":     os.path.exists(
                os.path.join(MODELS_DIR, "random_forest.pkl")),
            "LSTM model":        os.path.exists(
                os.path.join(MODELS_DIR, "lstm_model.h5")),
        }
        for name, ok in checks.items():
            icon = "✅" if ok else "⬜"
            color = "#10b981" if ok else "#64748b"
            st.markdown(
                f"<div style='font-size:0.82rem;color:{color};padding:0.15rem 0;'>"
                f"{icon} {name}</div>",
                unsafe_allow_html=True,
            )

        st.divider()
        st.caption("Built with ❤️ using Streamlit, scikit-learn & TensorFlow")


# ===========================================================================
# TAB 1 — Prediction
# ===========================================================================

def render_predict_tab():
    st.markdown(
        """
        <div class='card'>
            <div class='card-title'>🔍 Analyse a News Article</div>
        """,
        unsafe_allow_html=True,
    )

    col_left, col_right = st.columns([3, 1], gap="large")

    with col_left:
        news_input = st.text_area(
            "Paste a news headline or article body below:",
            height=200,
            placeholder=(
                "e.g. "Scientists announce breakthrough discovery in renewable energy "
                "storage technology, publishing results in Nature...""
            ),
            key="news_input",
        )

    with col_right:
        st.markdown("**Select Model**")
        model_choice = st.selectbox(
            "Model",
            options=ALL_MODELS,
            format_func=lambda m: f"{MODEL_ICONS.get(m, '')} {m}",
            key="model_choice",
            label_visibility="collapsed",
        )

        st.markdown("<br>", unsafe_allow_html=True)

        # Model description
        desc = {
            "Logistic Regression": "Fast, interpretable linear classifier. Works great on TF-IDF features.",
            "Naive Bayes":         "Probabilistic model based on word frequency. Very fast training.",
            "SVM":                 "Margin-based classifier with strong generalisation.",
            "Random Forest":       "Ensemble of decision trees. Robust to overfitting.",
            "LSTM":                "Bidirectional LSTM that captures long-range text dependencies.",
            "ANN":                 "Lightweight embedding-averaged neural network.",
        }
        st.markdown(
            f"<div style='font-size:0.8rem;color:#64748b;line-height:1.5;'>"
            f"{desc.get(model_choice, '')}</div>",
            unsafe_allow_html=True,
        )

    st.markdown("</div>", unsafe_allow_html=True)

    # ── Upload batch CSV ──
    with st.expander("📁 Batch Prediction via CSV upload"):
        st.markdown(
            "<p style='font-size:0.88rem;color:#94a3b8;'>"
            "Upload a CSV with a column named <code>text</code> for batch analysis.</p>",
            unsafe_allow_html=True,
        )
        uploaded = st.file_uploader(
            "Upload CSV", type=["csv"], key="batch_upload", label_visibility="collapsed"
        )

    # ── Predict button ──
    predict_clicked = st.button("🔍 Analyse Article", key="predict_btn", use_container_width=True)

    # ── Result ──
    if predict_clicked:
        text_to_use = news_input.strip()
        if not text_to_use:
            st.warning("⚠️  Please paste some news text before clicking Analyse.")
            return

        with st.spinner(f"Running {model_choice} model …"):
            try:
                result = run_prediction(text_to_use, model_choice)
            except FileNotFoundError as e:
                st.error(
                    f"🚫 Model artefacts not found.\n\n"
                    f"Run the training pipeline first:\n\n"
                    f"```bash\n"
                    f"python src/data_loader.py\n"
                    f"python src/preprocess.py\n"
                    f"python src/train_ml_models.py\n"
                    f"python src/train_dl_model.py --arch lstm\n"
                    f"```\n\n_{e}_"
                )
                return
            except Exception as e:
                st.error(f"❌ Prediction error: {e}")
                return

        label = result["label"]
        conf = result["confidence"]
        is_real = label == "Real"

        st.markdown("<br>", unsafe_allow_html=True)

        # ── Result banner ──
        r_col1, r_col2, r_col3 = st.columns([1, 2, 1])
        with r_col2:
            css_class = "result-real" if is_real else "result-fake"
            icon = "🟢" if is_real else "🔴"
            color = "#10b981" if is_real else "#ef4444"
            st.markdown(
                f"""
                <div class='{css_class}'>
                    <div style='font-size:2.8rem;'>{icon}</div>
                    <div class='result-label' style='color:{color};'>{label}</div>
                    <div class='result-conf'>
                        Confidence: <strong>{conf:.1%}</strong>
                    </div>
                    <div style='margin-top:0.6rem;font-size:0.82rem;color:#94a3b8;'>
                        Analysed by <strong>{model_choice}</strong>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

        # ── Confidence progress bar ──
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown(
            f"<p style='color:#94a3b8;font-size:0.9rem;text-align:center;'>"
            f"Confidence Score</p>",
            unsafe_allow_html=True,
        )
        st.progress(conf)

        # ── 4-metric tiles (if metrics exist) ──
        metrics_df = load_metrics_df()
        row = metrics_df[metrics_df["model"].str.lower().str.replace(" ", "") ==
                         model_choice.lower().replace(" ", "")]
        if not row.empty:
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown(
                "<p style='text-align:center;color:#64748b;font-size:0.82rem;'>"
                "Model performance on held-out test set</p>",
                unsafe_allow_html=True,
            )
            m1, m2, m3, m4 = st.columns(4)
            for col, key, name in [
                (m1, "accuracy", "Accuracy"),
                (m2, "precision", "Precision"),
                (m3, "recall", "Recall"),
                (m4, "f1", "F1 Score"),
            ]:
                val = row.iloc[0][key]
                with col:
                    st.markdown(
                        f"""
                        <div class='metric-tile'>
                            <div class='metric-val'>{val:.3f}</div>
                            <div class='metric-name'>{name}</div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

    # ── Batch results ──
    if uploaded is not None:
        st.markdown("---")
        st.subheader("📊 Batch Results")
        try:
            batch_df = pd.read_csv(uploaded)
            if "text" not in batch_df.columns:
                st.error("CSV must have a column named `text`.")
            else:
                selected_model = st.selectbox(
                    "Select model for batch prediction:",
                    ALL_MODELS,
                    key="batch_model",
                )
                if st.button("Run Batch Prediction", key="batch_run"):
                    with st.spinner("Predicting …"):
                        results = []
                        for txt in batch_df["text"].fillna(""):
                            try:
                                r = run_prediction(str(txt), selected_model)
                                results.append(r)
                            except Exception:
                                results.append({"label": "Error", "confidence": 0.0})
                        result_df = pd.DataFrame(results)
                        out_df = pd.concat(
                            [batch_df.reset_index(drop=True), result_df], axis=1
                        )
                        st.dataframe(out_df, use_container_width=True)
                        csv_bytes = out_df.to_csv(index=False).encode()
                        st.download_button(
                            "⬇️ Download Results CSV",
                            csv_bytes,
                            "batch_predictions.csv",
                            "text/csv",
                        )
        except Exception as e:
            st.error(f"Failed to process CSV: {e}")


# ===========================================================================
# TAB 2 — Model Comparison
# ===========================================================================

def render_comparison_tab():
    st.markdown(
        """
        <div class='card'>
            <div class='card-title'>📈 Model Performance Comparison</div>
        """,
        unsafe_allow_html=True,
    )

    metrics_df = load_metrics_df()

    if metrics_df.empty:
        st.info(
            "No metrics found yet. Train models first:\n\n"
            "```bash\npython src/train_ml_models.py\npython src/train_dl_model.py --arch lstm\n```"
        )
        st.markdown("</div>", unsafe_allow_html=True)
        return

    # ── Metrics table ──
    display_df = metrics_df.copy()
    for col in ["accuracy", "precision", "recall", "f1"]:
        if col in display_df.columns:
            display_df[col] = display_df[col].apply(lambda v: f"{v:.4f}")
    display_df.columns = [c.capitalize() for c in display_df.columns]
    st.dataframe(display_df, use_container_width=True, hide_index=True)

    st.markdown("</div>", unsafe_allow_html=True)

    # ── Bar chart ──
    st.markdown("<div class='card'><div class='card-title'>📊 Grouped Bar Chart</div>",
                unsafe_allow_html=True)
    fig = make_comparison_bar(metrics_df)
    st.pyplot(fig, use_container_width=True)
    plt.close(fig)
    st.markdown("</div>", unsafe_allow_html=True)

    # ── Highlight best model ──
    best = metrics_df.iloc[0]
    st.success(
        f"🏆 **Best model by F1 Score:** {best['model']} "
        f"(F1 = {best['f1']:.4f}, Accuracy = {best['accuracy']:.4f})"
    )

    # ── DL training curves ──
    curves_fig = make_training_curves_fig()
    if curves_fig is not None:
        st.markdown("<div class='card'><div class='card-title'>🧠 DL Training Curves</div>",
                    unsafe_allow_html=True)
        st.pyplot(curves_fig, use_container_width=True)
        plt.close(curves_fig)
        st.markdown("</div>", unsafe_allow_html=True)


# ===========================================================================
# TAB 3 — Confusion Matrix
# ===========================================================================

def render_confusion_tab():
    st.markdown(
        """
        <div class='card'>
            <div class='card-title'>🔲 Confusion Matrix</div>
        """,
        unsafe_allow_html=True,
    )

    selected = st.selectbox(
        "Select model to view confusion matrix:",
        ALL_MODELS,
        format_func=lambda m: f"{MODEL_ICONS.get(m, '')} {m}",
        key="cm_model_select",
    )

    st.markdown("</div>", unsafe_allow_html=True)

    fig = make_cm_plot(selected)
    if fig is None:
        st.info(
            f"No confusion matrix found for **{selected}**.\n\n"
            "It will appear here after training."
        )
    else:
        col_a, col_b, col_c = st.columns([1, 3, 1])
        with col_b:
            st.pyplot(fig, use_container_width=True)
        plt.close(fig)

    # ── Explanation ──
    st.markdown(
        """
        <div class='card' style='margin-top:1.5rem;'>
            <div class='card-title'>ℹ️ Reading the Matrix</div>
            <div style='font-size:0.88rem;color:#94a3b8;line-height:1.8;'>
                <ul style='padding-left:1.2rem;'>
                    <li><strong style='color:#10b981;'>True Positives (bottom-right)</strong> — Real articles correctly identified</li>
                    <li><strong style='color:#10b981;'>True Negatives (top-left)</strong> — Fake articles correctly identified</li>
                    <li><strong style='color:#ef4444;'>False Positives (top-right)</strong> — Fake articles misclassified as Real</li>
                    <li><strong style='color:#ef4444;'>False Negatives (bottom-left)</strong> — Real articles misclassified as Fake</li>
                </ul>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ===========================================================================
# TAB 4 — About
# ===========================================================================

def render_about_tab():
    st.markdown(
        """
        <div class='card'>
            <div class='card-title'>🎯 About This Project</div>
            <p style='color:#94a3b8;font-size:0.93rem;line-height:1.8;'>
                <strong style='color:#a5b4fc;'>FakeShield</strong> is an end-to-end Machine Learning &amp; Deep Learning
                system for detecting fake news. It combines classical NLP (TF-IDF) with modern neural
                architectures (LSTM, ANN) to provide robust, multi-model analysis.
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(
            """
            <div class='card'>
                <div class='card-title'>🧰 ML Models</div>
                <ul style='color:#94a3b8;font-size:0.88rem;line-height:2;padding-left:1.2rem;'>
                    <li>📊 Logistic Regression (TF-IDF)</li>
                    <li>📐 Multinomial Naive Bayes</li>
                    <li>⚡ Support Vector Machine (LinearSVC + calibration)</li>
                    <li>🌲 Random Forest (200 trees)</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True,
        )
    with col2:
        st.markdown(
            """
            <div class='card'>
                <div class='card-title'>🧠 Deep Learning Models</div>
                <ul style='color:#94a3b8;font-size:0.88rem;line-height:2;padding-left:1.2rem;'>
                    <li>🧠 Bidirectional LSTM with Dropout</li>
                    <li>🔬 Lightweight ANN (GlobalAveragePooling)</li>
                    <li>📦 Keras Embedding layer (trained end-to-end)</li>
                    <li>🛑 Early stopping + model checkpointing</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown(
        """
        <div class='card'>
            <div class='card-title'>🔄 Pipeline</div>
            <div style='display:flex;gap:1rem;flex-wrap:wrap;align-items:center;justify-content:center;'>
        """,
        unsafe_allow_html=True,
    )
    steps = [
        ("📥", "Raw Data", "Fake.csv + True.csv"),
        ("🧹", "Preprocess", "Clean, lemmatize, remove stopwords"),
        ("⚙️", "Features", "TF-IDF / Keras sequences"),
        ("🤖", "Train", "ML + DL models"),
        ("📊", "Evaluate", "Accuracy, F1, Confusion Matrix"),
        ("🛡️", "Predict", "Real or Fake + confidence"),
    ]
    cols = st.columns(len(steps))
    for col, (icon, title, desc) in zip(cols, steps):
        with col:
            st.markdown(
                f"""
                <div style='text-align:center;background:rgba(99,102,241,0.08);
                            border:1px solid rgba(99,102,241,0.2);border-radius:12px;
                            padding:1rem 0.5rem;'>
                    <div style='font-size:1.8rem;'>{icon}</div>
                    <div style='font-family:Outfit,sans-serif;font-weight:600;
                                color:#a5b4fc;font-size:0.9rem;margin-top:0.3rem;'>{title}</div>
                    <div style='font-size:0.72rem;color:#64748b;margin-top:0.3rem;
                                line-height:1.4;'>{desc}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

    st.markdown("</div></div>", unsafe_allow_html=True)


# ===========================================================================
# Main Layout
# ===========================================================================

def main():
    render_sidebar()

    # ── Hero banner ──
    st.markdown(
        """
        <div class='hero-banner'>
            <div style='display:flex;align-items:center;gap:1rem;'>
                <span style='font-size:3.5rem;'>🛡️</span>
                <div>
                    <h1 class='hero-title'>FakeShield</h1>
                    <p class='hero-sub'>
                        AI-powered Fake News Detection · ML + Deep Learning · Multi-model Analysis
                    </p>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── Tabs ──
    tab1, tab2, tab3, tab4 = st.tabs(
        ["🔍 Predict", "📈 Model Comparison", "🔲 Confusion Matrix", "ℹ️ About"]
    )

    with tab1:
        render_predict_tab()

    with tab2:
        render_comparison_tab()

    with tab3:
        render_confusion_tab()

    with tab4:
        render_about_tab()


if __name__ == "__main__":
    main()
