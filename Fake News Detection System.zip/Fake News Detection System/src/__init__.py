# src/__init__.py
# Makes 'src' a proper Python package so cross-module imports work correctly.
