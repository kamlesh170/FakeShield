from __future__ import annotations
"""
data_loader.py
--------------
Loads Fake.csv and True.csv from data/raw/, labels them,
merges title + text into a single 'content' column, combines
both DataFrames, removes duplicates/nulls, and performs a
stratified 80/20 train-test split.

Run standalone:
    python src/data_loader.py
"""

import os
import sys
import logging
import pandas as pd
from sklearn.model_selection import train_test_split

# ---------------------------------------------------------------------------
# Paths (all relative to project root, not this file)
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RAW_DIR = os.path.join(PROJECT_ROOT, "data", "raw")
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")

FAKE_CSV = os.path.join(RAW_DIR, "Fake.csv")
TRUE_CSV = os.path.join(RAW_DIR, "True.csv")

TRAIN_OUT = os.path.join(PROCESSED_DIR, "train.csv")
TEST_OUT = os.path.join(PROCESSED_DIR, "test.csv")

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _load_single(path: str, label: int) -> pd.DataFrame:
    """
    Load a single CSV file, add a numeric label column, and return it.

    Parameters
    ----------
    path  : Absolute path to the CSV file.
    label : 0 for fake, 1 for real.

    Returns
    -------
    pd.DataFrame with columns [title, text, subject, date, label]
    """
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset file not found: {path}\n"
            "Download 'Fake and Real News Dataset' from Kaggle and place "
            "Fake.csv and True.csv inside  data/raw/"
        )
    df = pd.read_csv(path)
    df["label"] = label
    log.info("Loaded %s  →  %d rows, label=%d", os.path.basename(path), len(df), label)
    return df


def _merge_content(df: pd.DataFrame) -> pd.DataFrame:
    """
    Merge 'title' and 'text' into a single 'content' column.
    Falls back gracefully if either column is absent.
    """
    has_title = "title" in df.columns
    has_text = "text" in df.columns

    if has_title and has_text:
        df["content"] = df["title"].fillna("") + " " + df["text"].fillna("")
    elif has_text:
        df["content"] = df["text"].fillna("")
    elif has_title:
        df["content"] = df["title"].fillna("")
    else:
        raise ValueError("DataFrame has neither 'title' nor 'text' column.")

    return df


def load_and_prepare() -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Full data-loading pipeline.

    Returns
    -------
    (train_df, test_df) – both with columns [content, label]
    """
    os.makedirs(PROCESSED_DIR, exist_ok=True)

    # 1. Load individual files
    fake_df = _load_single(FAKE_CSV, label=0)
    true_df = _load_single(TRUE_CSV, label=1)

    # 2. Combine
    combined = pd.concat([fake_df, true_df], ignore_index=True)
    log.info("Combined dataset: %d rows", len(combined))

    # 3. Merge title + text → content
    combined = _merge_content(combined)

    # 4. Keep only needed columns
    combined = combined[["content", "label"]]

    # 5. Drop nulls and duplicates
    before = len(combined)
    combined.dropna(subset=["content"], inplace=True)
    combined.drop_duplicates(subset=["content"], inplace=True)
    after = len(combined)
    log.info("After cleaning: %d rows  (removed %d)", after, before - after)

    # 6. Remove rows where content is whitespace-only
    combined = combined[combined["content"].str.strip().astype(bool)]

    # 7. Stratified 80/20 split
    train_df, test_df = train_test_split(
        combined,
        test_size=0.20,
        random_state=42,
        stratify=combined["label"],
        shuffle=True,
    )
    log.info("Train: %d rows | Test: %d rows", len(train_df), len(test_df))

    # 8. Save
    train_df.to_csv(TRAIN_OUT, index=False)
    test_df.to_csv(TEST_OUT, index=False)
    log.info("Saved → %s", TRAIN_OUT)
    log.info("Saved → %s", TEST_OUT)

    return train_df.reset_index(drop=True), test_df.reset_index(drop=True)


def load_processed() -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Load already-processed train/test CSVs without re-running the pipeline.
    Raises FileNotFoundError if they don't exist (run load_and_prepare first).
    """
    for path in [TRAIN_OUT, TEST_OUT]:
        if not os.path.exists(path):
            raise FileNotFoundError(
                f"Processed file missing: {path}\n"
                "Run  python src/data_loader.py  first."
            )
    train_df = pd.read_csv(TRAIN_OUT)
    test_df = pd.read_csv(TEST_OUT)
    return train_df, test_df


# ---------------------------------------------------------------------------
# Standalone entry-point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    try:
        train, test = load_and_prepare()
        print(f"\n✅  Data loading complete.")
        print(f"   Train shape : {train.shape}")
        print(f"   Test shape  : {test.shape}")
        print(f"   Label dist  (train):\n{train['label'].value_counts()}")
    except FileNotFoundError as exc:
        log.error(str(exc))
        sys.exit(1)
