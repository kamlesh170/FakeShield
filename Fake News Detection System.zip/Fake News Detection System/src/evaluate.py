from __future__ import annotations
"""
evaluate.py
-----------
Shared evaluation utilities used by both ML and DL training scripts
and by the Streamlit dashboard.

Functions
---------
evaluate_model(y_true, y_pred, y_prob=None)
    → dict with accuracy, precision, recall, F1

plot_confusion_matrix(y_true, y_pred, model_name, save_path=None)
    → matplotlib Figure

build_comparison_table(results_dict)
    → pd.DataFrame with one row per model
"""

import os
import logging

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # non-interactive backend — safe for server use
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)

# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")


# ===========================================================================
# Core metrics
# ===========================================================================

def evaluate_model(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: np.ndarray | None = None,
    model_name: str = "Model",
    verbose: bool = True,
) -> dict:
    """
    Compute classification metrics for a binary classifier.

    Parameters
    ----------
    y_true      : Ground-truth labels (0 / 1).
    y_pred      : Predicted labels (0 / 1).
    y_prob      : Predicted probabilities for class 1 (optional).
    model_name  : Display name logged to console.
    verbose     : Print classification report if True.

    Returns
    -------
    dict with keys: accuracy, precision, recall, f1
    """
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="binary", zero_division=0)
    rec = recall_score(y_true, y_pred, average="binary", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="binary", zero_division=0)

    metrics = {
        "model": model_name,
        "accuracy": round(acc, 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1": round(f1, 4),
    }

    if verbose:
        log.info(
            "%s — Acc: %.4f | Prec: %.4f | Rec: %.4f | F1: %.4f",
            model_name, acc, prec, rec, f1,
        )
        print(f"\n{'='*55}")
        print(f"  {model_name}")
        print(f"{'='*55}")
        print(classification_report(y_true, y_pred, target_names=["Fake", "Real"]))

    return metrics


# ===========================================================================
# Confusion matrix plot
# ===========================================================================

def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str = "Model",
    save_path: str | None = None,
) -> plt.Figure:
    """
    Generate and optionally save a seaborn confusion-matrix heatmap.

    Parameters
    ----------
    y_true      : Ground-truth labels.
    y_pred      : Predicted labels.
    model_name  : Title suffix.
    save_path   : If given, save the figure to this path as PNG.

    Returns
    -------
    matplotlib.figure.Figure (caller must close it when done)
    """
    cm = confusion_matrix(y_true, y_pred)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        linewidths=0.5,
        xticklabels=["Fake (0)", "Real (1)"],
        yticklabels=["Fake (0)", "Real (1)"],
        ax=ax,
    )
    ax.set_xlabel("Predicted label", fontsize=12)
    ax.set_ylabel("True label", fontsize=12)
    ax.set_title(f"Confusion Matrix — {model_name}", fontsize=13, fontweight="bold")
    fig.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        fig.savefig(save_path, dpi=120, bbox_inches="tight")
        log.info("Confusion matrix saved → %s", save_path)

    return fig


# ===========================================================================
# Comparison table
# ===========================================================================

def build_comparison_table(results: list[dict]) -> pd.DataFrame:
    """
    Build a tidy comparison DataFrame from a list of metric dicts.

    Parameters
    ----------
    results : List of dicts returned by evaluate_model().

    Returns
    -------
    pd.DataFrame with columns [model, accuracy, precision, recall, f1]
    sorted by F1 descending.
    """
    df = pd.DataFrame(results)
    df = df.sort_values("f1", ascending=False).reset_index(drop=True)
    return df


# ===========================================================================
# Bar-chart helper (used by dashboard)
# ===========================================================================

def plot_comparison_bar(comparison_df: pd.DataFrame) -> plt.Figure:
    """
    Generate a grouped bar chart comparing all models across four metrics.

    Parameters
    ----------
    comparison_df : DataFrame produced by build_comparison_table().

    Returns
    -------
    matplotlib.figure.Figure
    """
    metrics = ["accuracy", "precision", "recall", "f1"]
    models = comparison_df["model"].tolist()
    x = np.arange(len(models))
    bar_width = 0.18

    fig, ax = plt.subplots(figsize=(max(10, len(models) * 2), 5))

    colors = ["#4C72B0", "#55A868", "#C44E52", "#8172B2"]
    for i, (metric, color) in enumerate(zip(metrics, colors)):
        offset = (i - 1.5) * bar_width
        bars = ax.bar(
            x + offset,
            comparison_df[metric].values,
            width=bar_width,
            label=metric.capitalize(),
            color=color,
            alpha=0.85,
        )
        # Annotate bars
        for bar in bars:
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{bar.get_height():.3f}",
                ha="center",
                va="bottom",
                fontsize=7.5,
            )

    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=15, ha="right", fontsize=10)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score", fontsize=11)
    ax.set_title("Model Comparison — All Metrics", fontsize=13, fontweight="bold")
    ax.legend(loc="upper right", fontsize=10)
    ax.grid(axis="y", linestyle="--", alpha=0.5)
    fig.tight_layout()
    return fig
