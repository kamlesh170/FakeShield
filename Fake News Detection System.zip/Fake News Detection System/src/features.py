from __future__ import annotations
"""
features.py
-----------
Feature extraction for the Fake-News Detection pipeline.

Provides:
  - TF-IDF vectorisation (for ML models)
  - Keras Tokenizer + padded sequences (for the DL model)
  - (Optional) Word2Vec embeddings via gensim — commented extension at bottom

Saved artefacts (in models/):
  tfidf_vectorizer.pkl   — fitted TfidfVectorizer
  keras_tokenizer.pkl    — fitted Keras Tokenizer
  word_index.pkl         — mapping word → integer index

Run standalone to build and save both extractors:
    python src/features.py
"""

import os
import sys
import logging
import pickle

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")

TRAIN_CLEAN = os.path.join(PROCESSED_DIR, "train_clean.csv")
TEST_CLEAN = os.path.join(PROCESSED_DIR, "test_clean.csv")

TFIDF_PATH = os.path.join(MODELS_DIR, "tfidf_vectorizer.pkl")
TOKENIZER_PATH = os.path.join(MODELS_DIR, "keras_tokenizer.pkl")
WORD_INDEX_PATH = os.path.join(MODELS_DIR, "word_index.pkl")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
TFIDF_MAX_FEATURES = 5000
TFIDF_NGRAM_RANGE = (1, 2)

KERAS_MAX_WORDS = 10_000   # vocabulary size cap
KERAS_MAX_LEN = 300        # max sequence length after padding

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# ===========================================================================
# TF-IDF (for ML models)
# ===========================================================================

def build_tfidf(
    train_texts: list[str],
    max_features: int = TFIDF_MAX_FEATURES,
    ngram_range: tuple = TFIDF_NGRAM_RANGE,
) -> TfidfVectorizer:
    """
    Fit a TfidfVectorizer on *train_texts* and return it.

    Parameters
    ----------
    train_texts  : List / Series of cleaned text strings.
    max_features : Vocabulary cap.
    ngram_range  : Tuple (min_n, max_n) for n-gram extraction.

    Returns
    -------
    Fitted TfidfVectorizer instance.
    """
    log.info("Fitting TF-IDF (max_features=%d, ngrams=%s) …", max_features, ngram_range)
    vectorizer = TfidfVectorizer(
        max_features=max_features,
        ngram_range=ngram_range,
        sublinear_tf=True,       # apply log(1+tf) scaling
        strip_accents="unicode",
        analyzer="word",
        min_df=2,                # ignore very rare terms
    )
    vectorizer.fit(train_texts)
    log.info("TF-IDF vocabulary size: %d", len(vectorizer.vocabulary_))
    return vectorizer


def transform_tfidf(
    vectorizer: TfidfVectorizer,
    texts: list[str],
) -> np.ndarray:
    """
    Transform texts into a sparse TF-IDF matrix.
    Returns a scipy sparse matrix (compatible with scikit-learn models).
    """
    return vectorizer.transform(texts)


def save_tfidf(vectorizer: TfidfVectorizer, path: str = TFIDF_PATH) -> None:
    """Persist a fitted TfidfVectorizer to disk with pickle."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(vectorizer, f)
    log.info("TF-IDF vectorizer saved → %s", path)


def load_tfidf(path: str = TFIDF_PATH) -> TfidfVectorizer:
    """Load a persisted TfidfVectorizer from disk."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"TF-IDF vectorizer not found: {path}")
    with open(path, "rb") as f:
        return pickle.load(f)


# ===========================================================================
# Keras Tokenizer + padded sequences (for DL model)
# ===========================================================================

def build_keras_tokenizer(train_texts: list[str], max_words: int = KERAS_MAX_WORDS):
    """
    Fit a Keras Tokenizer on *train_texts* and return it.

    Parameters
    ----------
    train_texts : List / Series of cleaned strings.
    max_words   : Maximum vocabulary size.

    Returns
    -------
    Fitted tensorflow.keras.preprocessing.text.Tokenizer.
    """
    # Import here so TensorFlow is not loaded unless needed
    from tensorflow.keras.preprocessing.text import Tokenizer  # type: ignore

    log.info("Fitting Keras Tokenizer (max_words=%d) …", max_words)
    tokenizer = Tokenizer(num_words=max_words, oov_token="<OOV>")
    tokenizer.fit_on_texts(train_texts)
    log.info("Keras vocab size: %d", len(tokenizer.word_index))
    return tokenizer


def texts_to_sequences(
    tokenizer,
    texts: list[str],
    max_len: int = KERAS_MAX_LEN,
) -> np.ndarray:
    """
    Convert texts to zero-padded integer sequences.

    Parameters
    ----------
    tokenizer : Fitted Keras Tokenizer.
    texts     : Iterable of text strings.
    max_len   : Pad / truncate to this length.

    Returns
    -------
    numpy array of shape (n_samples, max_len).
    """
    from tensorflow.keras.preprocessing.sequence import pad_sequences  # type: ignore

    seqs = tokenizer.texts_to_sequences(texts)
    padded = pad_sequences(seqs, maxlen=max_len, padding="post", truncating="post")
    return padded


def save_keras_tokenizer(tokenizer, path: str = TOKENIZER_PATH) -> None:
    """Persist a fitted Keras Tokenizer to disk with pickle."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        pickle.dump(tokenizer, f)
    log.info("Keras tokenizer saved → %s", path)


def load_keras_tokenizer(path: str = TOKENIZER_PATH):
    """Load a persisted Keras Tokenizer from disk."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Keras tokenizer not found: {path}")
    with open(path, "rb") as f:
        return pickle.load(f)


# ===========================================================================
# (Optional extension) Word2Vec via gensim
# ===========================================================================
# Uncomment the block below to train and use Word2Vec embeddings.
#
# from gensim.models import Word2Vec
#
# def build_word2vec(tokenized_corpus: list[list[str]], vector_size=100, window=5,
#                    min_count=2, workers=4) -> Word2Vec:
#     """Train a Word2Vec model on the tokenized corpus."""
#     model = Word2Vec(
#         sentences=tokenized_corpus,
#         vector_size=vector_size,
#         window=window,
#         min_count=min_count,
#         workers=workers,
#     )
#     return model
#
# def get_w2v_embedding(text_tokens: list[str], w2v_model: Word2Vec) -> np.ndarray:
#     """Average Word2Vec embeddings for a list of tokens → single vector."""
#     vecs = [w2v_model.wv[t] for t in text_tokens if t in w2v_model.wv]
#     return np.mean(vecs, axis=0) if vecs else np.zeros(w2v_model.vector_size)


# ===========================================================================
# Standalone entry-point
# ===========================================================================
if __name__ == "__main__":
    for path in [TRAIN_CLEAN, TEST_CLEAN]:
        if not os.path.exists(path):
            log.error("Missing %s — run  python src/preprocess.py  first.", path)
            sys.exit(1)

    os.makedirs(MODELS_DIR, exist_ok=True)

    train_df = pd.read_csv(TRAIN_CLEAN)
    test_df = pd.read_csv(TEST_CLEAN)

    train_texts = train_df["clean_content"].fillna("").tolist()
    test_texts = test_df["clean_content"].fillna("").tolist()

    # --- TF-IDF ---
    tfidf = build_tfidf(train_texts)
    X_train_tfidf = transform_tfidf(tfidf, train_texts)
    X_test_tfidf = transform_tfidf(tfidf, test_texts)
    save_tfidf(tfidf)
    print(f"TF-IDF train shape : {X_train_tfidf.shape}")
    print(f"TF-IDF test  shape : {X_test_tfidf.shape}")

    # --- Keras Tokenizer ---
    keras_tok = build_keras_tokenizer(train_texts)
    X_train_seq = texts_to_sequences(keras_tok, train_texts)
    X_test_seq = texts_to_sequences(keras_tok, test_texts)
    save_keras_tokenizer(keras_tok)
    print(f"Keras sequences train shape : {X_train_seq.shape}")
    print(f"Keras sequences test  shape : {X_test_seq.shape}")

    print("\n✅  Feature extraction complete.")
