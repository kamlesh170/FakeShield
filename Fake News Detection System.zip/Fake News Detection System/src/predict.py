from __future__ import annotations
"""
predict.py
----------
Single-text and batch prediction interface.

Public API
----------
predict_news(text, model_choice) → dict
    Keys: label ("Real" / "Fake"), confidence (float 0-1), model_choice

Supports all five models:
  'Logistic Regression', 'Naive Bayes', 'SVM', 'Random Forest',
  'LSTM', 'ANN'

Usage example:
    from src.predict import predict_news
    result = predict_news("Breaking: Scientists discover miracle cure", "Logistic Regression")
    print(result)  # {'label': 'Fake', 'confidence': 0.87, 'model_choice': 'Logistic Regression'}
"""

import os
import sys
import logging

import numpy as np

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))   # make sibling imports work

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# ML model names
# ---------------------------------------------------------------------------
ML_MODEL_NAMES = {"Logistic Regression", "Naive Bayes", "SVM", "Random Forest"}
DL_MODEL_NAMES = {"LSTM", "ANN"}
ALL_MODEL_NAMES = ML_MODEL_NAMES | DL_MODEL_NAMES

# DL architecture string used by train_dl_model.py
_DL_ARCH_MAP = {"LSTM": "lstm", "ANN": "ann"}


# ===========================================================================
# Core prediction function
# ===========================================================================

def predict_news(text: str, model_choice: str) -> dict:
    """
    Predict whether a news article is Fake or Real.

    Parameters
    ----------
    text         : Raw headline or article body (un-cleaned).
    model_choice : One of the strings in ALL_MODEL_NAMES.

    Returns
    -------
    dict with keys:
      label       – "Fake" or "Real"
      confidence  – float in [0, 1] (probability of the predicted class)
      model_choice – echo of the model used

    Raises
    ------
    ValueError         : Empty or whitespace-only input text.
    ValueError         : Unknown model_choice.
    FileNotFoundError  : Required model / vectorizer file missing.
    """
    # --- Input validation ---
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Input text must be a non-empty string.")

    model_choice = model_choice.strip()
    if model_choice not in ALL_MODEL_NAMES:
        raise ValueError(
            f"Unknown model '{model_choice}'. "
            f"Choose from: {sorted(ALL_MODEL_NAMES)}"
        )

    # --- Clean text ---
    from preprocess import clean_text
    cleaned = clean_text(text)

    if not cleaned.strip():
        raise ValueError(
            "Text is empty after cleaning. "
            "Please provide a longer, more descriptive input."
        )

    # --- Route to ML or DL branch ---
    if model_choice in ML_MODEL_NAMES:
        label, confidence = _predict_ml(cleaned, model_choice)
    else:
        label, confidence = _predict_dl(cleaned, _DL_ARCH_MAP[model_choice])

    return {
        "label": label,
        "confidence": float(round(confidence, 4)),
        "model_choice": model_choice,
    }


# ===========================================================================
# ML branch
# ===========================================================================

def _predict_ml(cleaned_text: str, model_name: str) -> tuple[str, float]:
    """Use TF-IDF + sklearn model to predict a single cleaned text."""
    from features import load_tfidf, transform_tfidf
    from train_ml_models import load_model

    # Load artefacts (fast from cache on repeated calls)
    vectorizer = load_tfidf()
    model = load_model(model_name)

    # Transform
    X = transform_tfidf(vectorizer, [cleaned_text])

    # Predict
    y_pred = model.predict(X)[0]

    if hasattr(model, "predict_proba"):
        probs = model.predict_proba(X)[0]
        confidence = float(probs[y_pred])
    else:
        confidence = 1.0   # hard classifiers without probability support

    label = "Real" if y_pred == 1 else "Fake"
    return label, confidence


# ===========================================================================
# DL branch
# ===========================================================================

def _predict_dl(cleaned_text: str, arch: str) -> tuple[str, float]:
    """Use Keras tokenizer + LSTM/ANN model to predict a single cleaned text."""
    from features import load_keras_tokenizer, texts_to_sequences, KERAS_MAX_LEN
    from train_dl_model import load_dl_model

    tokenizer = load_keras_tokenizer()
    model = load_dl_model(arch)

    X = texts_to_sequences(tokenizer, [cleaned_text], max_len=KERAS_MAX_LEN)
    prob = float(model.predict(X, verbose=0).ravel()[0])

    # prob ≈ P(Real)
    if prob >= 0.5:
        label, confidence = "Real", prob
    else:
        label, confidence = "Fake", 1.0 - prob

    return label, confidence


# ===========================================================================
# Batch prediction
# ===========================================================================

def predict_batch(texts: list[str], model_choice: str) -> list[dict]:
    """
    Run predict_news on a list of texts.

    Invalid rows are returned with label='Error' and confidence=0.0.
    """
    results = []
    for text in texts:
        try:
            results.append(predict_news(text, model_choice))
        except Exception as exc:
            results.append(
                {"label": "Error", "confidence": 0.0, "model_choice": model_choice, "error": str(exc)}
            )
    return results


# ===========================================================================
# CLI entry-point (quick smoke test)
# ===========================================================================
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Predict a news article")
    parser.add_argument("text", help="News text to classify")
    parser.add_argument(
        "--model",
        default="Logistic Regression",
        choices=sorted(ALL_MODEL_NAMES),
        help="Model to use for prediction",
    )
    args = parser.parse_args()

    try:
        result = predict_news(args.text, args.model)
        icon = "🟢" if result["label"] == "Real" else "🔴"
        print(f"\n{icon}  {result['label']}  —  confidence: {result['confidence']:.2%}")
        print(f"   Model used: {result['model_choice']}")
    except (ValueError, FileNotFoundError) as exc:
        log.error(str(exc))
        sys.exit(1)
