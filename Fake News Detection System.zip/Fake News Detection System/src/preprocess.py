from __future__ import annotations
"""
preprocess.py
-------------
Text-cleaning utilities used across the entire pipeline.

Key function: clean_text(text) → str

Steps applied (in order):
  1. Lowercase
  2. Remove URLs
  3. Remove HTML tags
  4. Remove punctuation, numbers, special characters
  5. Tokenise
  6. Remove NLTK stopwords
  7. Lemmatize with WordNetLemmatizer
     (PorterStemmer is available as an alternative — see _stem_tokens)

Run standalone to pre-process train/test splits and cache them:
    python src/preprocess.py
"""

import os
import re
import logging
import pickle

import nltk
import pandas as pd
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer, PorterStemmer
from nltk.tokenize import word_tokenize

# ---------------------------------------------------------------------------
# Ensure required NLTK data is available
# ---------------------------------------------------------------------------
_NLTK_PKGS = ["punkt", "stopwords", "wordnet", "omw-1.4", "punkt_tab"]

def _ensure_nltk_data() -> None:
    """Download NLTK corpora silently if not already present."""
    for pkg in _NLTK_PKGS:
        try:
            nltk.data.find(f"tokenizers/{pkg}")
        except LookupError:
            try:
                nltk.data.find(f"corpora/{pkg}")
            except LookupError:
                nltk.download(pkg, quiet=True)


_ensure_nltk_data()

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
TRAIN_RAW = os.path.join(PROCESSED_DIR, "train.csv")
TEST_RAW = os.path.join(PROCESSED_DIR, "test.csv")
TRAIN_CLEAN = os.path.join(PROCESSED_DIR, "train_clean.csv")
TEST_CLEAN = os.path.join(PROCESSED_DIR, "test_clean.csv")

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Singletons (initialised once)
# ---------------------------------------------------------------------------
_lemmatizer = WordNetLemmatizer()
_stemmer = PorterStemmer()  # alternative to lemmatizer
_stop_words = set(stopwords.words("english"))

# ---------------------------------------------------------------------------
# Regex patterns compiled at module load for speed
# ---------------------------------------------------------------------------
_RE_URL = re.compile(r"https?://\S+|www\.\S+")
_RE_HTML = re.compile(r"<[^>]+>")
_RE_PUNCT_NUM = re.compile(r"[^a-z\s]")   # keep only lowercase letters + whitespace
_RE_WHITESPACE = re.compile(r"\s+")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _lemmatize_tokens(tokens: list[str]) -> list[str]:
    """Return lemmatized tokens using WordNetLemmatizer."""
    return [_lemmatizer.lemmatize(t) for t in tokens]


def _stem_tokens(tokens: list[str]) -> list[str]:
    """
    Alternative: return stemmed tokens using PorterStemmer.
    Swap this in place of _lemmatize_tokens if preferred.
    """
    return [_stemmer.stem(t) for t in tokens]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def clean_text(text: str, use_stemming: bool = False) -> str:
    """
    Clean and normalise a raw news text string.

    Parameters
    ----------
    text         : Raw input string (headline + body).
    use_stemming : If True, apply PorterStemmer instead of lemmatization.

    Returns
    -------
    Cleaned string with tokens joined by spaces.

    Raises
    ------
    TypeError  : If text is not a string-like object.
    """
    if not isinstance(text, str):
        try:
            text = str(text)
        except Exception:
            return ""

    # 1. Lowercase
    text = text.lower()

    # 2. Remove URLs
    text = _RE_URL.sub(" ", text)

    # 3. Remove HTML tags
    text = _RE_HTML.sub(" ", text)

    # 4. Remove punctuation, numbers, special characters
    text = _RE_PUNCT_NUM.sub(" ", text)

    # 5. Collapse multiple whitespace
    text = _RE_WHITESPACE.sub(" ", text).strip()

    # 6. Tokenise
    tokens = word_tokenize(text)

    # 7. Remove stopwords
    tokens = [t for t in tokens if t not in _stop_words and len(t) > 1]

    # 8. Lemmatize (or stem)
    if use_stemming:
        tokens = _stem_tokens(tokens)
    else:
        tokens = _lemmatize_tokens(tokens)

    return " ".join(tokens)


def preprocess_dataframe(
    df: pd.DataFrame,
    text_col: str = "content",
    use_stemming: bool = False,
) -> pd.DataFrame:
    """
    Apply clean_text() to every row in `text_col` of *df*.

    Returns a copy of the DataFrame with an additional 'clean_content' column.
    """
    df = df.copy()
    log.info("Cleaning %d rows …", len(df))
    df["clean_content"] = df[text_col].apply(
        lambda t: clean_text(t, use_stemming=use_stemming)
    )
    # Drop rows that became empty after cleaning
    before = len(df)
    df = df[df["clean_content"].str.strip().astype(bool)]
    log.info("Rows after cleaning: %d  (removed %d empty)", len(df), before - len(df))
    return df.reset_index(drop=True)


# ---------------------------------------------------------------------------
# Standalone entry-point: pre-process & cache train/test splits
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    os.makedirs(PROCESSED_DIR, exist_ok=True)

    for raw_path, clean_path, split_name in [
        (TRAIN_RAW, TRAIN_CLEAN, "train"),
        (TEST_RAW, TEST_CLEAN, "test"),
    ]:
        if not os.path.exists(raw_path):
            log.error("Missing %s — run  python src/data_loader.py  first.", raw_path)
            sys.exit(1)

        df = pd.read_csv(raw_path)
        df_clean = preprocess_dataframe(df)
        df_clean.to_csv(clean_path, index=False)
        log.info("Saved cleaned %s → %s", split_name, clean_path)

    print("\n✅  Preprocessing complete.")
