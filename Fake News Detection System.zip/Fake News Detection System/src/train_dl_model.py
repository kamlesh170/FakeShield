from __future__ import annotations
"""
train_dl_model.py
-----------------
Train a deep-learning text classifier using TensorFlow / Keras.

Architecture options (selectable via CLI arg):
  --arch lstm   →  Embedding → Bidirectional LSTM → Dropout → Dense(1)
  --arch ann    →  Embedding → GlobalAveragePooling1D → Dense layers  (lighter)

Produces:
  models/lstm_model.h5          (or ann_model.h5)
  models/dl_training_curves.png
  models/dl_metrics.json        (accuracy, precision, recall, f1 on test set)

Run:
    python src/train_dl_model.py --arch lstm
    python src/train_dl_model.py --arch ann
"""

import os
import sys
import json
import argparse
import logging

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")

TRAIN_CLEAN = os.path.join(PROCESSED_DIR, "train_clean.csv")
TEST_CLEAN = os.path.join(PROCESSED_DIR, "test_clean.csv")
DL_METRICS_JSON = os.path.join(MODELS_DIR, "dl_metrics.json")
CURVES_PNG = os.path.join(MODELS_DIR, "dl_training_curves.png")

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)

# Constants
EMBEDDING_DIM = 64
MAX_WORDS = 10_000
MAX_LEN = 300
BATCH_SIZE = 128
EPOCHS = 20   # early stopping will halt training sooner


# ===========================================================================
# Architecture builders
# ===========================================================================

def build_lstm_model(vocab_size: int) -> "tf.keras.Model":  # noqa: F821
    """
    Bidirectional LSTM architecture.

    Layers:
      Embedding → Bidirectional(LSTM(64)) → Dropout(0.4)
             → Dense(32, relu) → Dropout(0.3) → Dense(1, sigmoid)
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model, Input  # type: ignore

    inp = Input(shape=(MAX_LEN,))
    x = layers.Embedding(vocab_size, EMBEDDING_DIM, mask_zero=True)(inp)
    x = layers.Bidirectional(layers.LSTM(64, return_sequences=False))(x)
    x = layers.Dropout(0.4)(x)
    x = layers.Dense(32, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    out = layers.Dense(1, activation="sigmoid")(x)

    model = Model(inp, out, name="BiLSTM_FakeNews")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )
    return model


def build_ann_model(vocab_size: int) -> "tf.keras.Model":  # noqa: F821
    """
    Lightweight ANN (bag-of-embeddings) architecture.

    Layers:
      Embedding → GlobalAveragePooling1D → Dense(64, relu)
             → Dropout(0.3) → Dense(32, relu) → Dense(1, sigmoid)
    """
    import tensorflow as tf
    from tensorflow.keras import layers, Model, Input  # type: ignore

    inp = Input(shape=(MAX_LEN,))
    x = layers.Embedding(vocab_size, EMBEDDING_DIM)(inp)
    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dense(64, activation="relu")(x)
    x = layers.Dropout(0.3)(x)
    x = layers.Dense(32, activation="relu")(x)
    out = layers.Dense(1, activation="sigmoid")(x)

    model = Model(inp, out, name="ANN_FakeNews")
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )
    return model


# ===========================================================================
# Training
# ===========================================================================

def train_dl_model(arch: str = "lstm") -> dict:
    """
    Full DL training pipeline.

    Parameters
    ----------
    arch : 'lstm' or 'ann'

    Returns
    -------
    dict of evaluation metrics
    """
    import tensorflow as tf
    from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint  # type: ignore

    sys.path.insert(0, os.path.dirname(__file__))
    from features import (
        build_keras_tokenizer,
        texts_to_sequences,
        save_keras_tokenizer,
        load_keras_tokenizer,
        TOKENIZER_PATH,
    )
    from evaluate import evaluate_model, plot_confusion_matrix
    import matplotlib.pyplot as plt

    os.makedirs(MODELS_DIR, exist_ok=True)

    # --- Load data ---
    train_df = pd.read_csv(TRAIN_CLEAN)
    test_df = pd.read_csv(TEST_CLEAN)
    train_texts = train_df["clean_content"].fillna("").tolist()
    test_texts = test_df["clean_content"].fillna("").tolist()
    y_train = train_df["label"].values.astype("float32")
    y_test = test_df["label"].values.astype("float32")

    # --- Tokenizer ---
    if os.path.exists(TOKENIZER_PATH):
        log.info("Loading existing Keras tokenizer …")
        tokenizer = load_keras_tokenizer()
    else:
        tokenizer = build_keras_tokenizer(train_texts, max_words=MAX_WORDS)
        save_keras_tokenizer(tokenizer)

    vocab_size = min(MAX_WORDS, len(tokenizer.word_index)) + 1

    X_train = texts_to_sequences(tokenizer, train_texts, max_len=MAX_LEN)
    X_test = texts_to_sequences(tokenizer, test_texts, max_len=MAX_LEN)

    log.info("X_train shape: %s  |  vocab_size: %d", X_train.shape, vocab_size)

    # --- Build model ---
    arch = arch.lower()
    if arch == "lstm":
        model = build_lstm_model(vocab_size)
        model_path = os.path.join(MODELS_DIR, "lstm_model.h5")
        display_name = "LSTM"
    elif arch == "ann":
        model = build_ann_model(vocab_size)
        model_path = os.path.join(MODELS_DIR, "ann_model.h5")
        display_name = "ANN"
    else:
        raise ValueError(f"Unknown arch '{arch}'. Choose 'lstm' or 'ann'.")

    model.summary()

    # --- Callbacks ---
    callbacks = [
        EarlyStopping(
            monitor="val_loss",
            patience=3,
            restore_best_weights=True,
            verbose=1,
        ),
        ModelCheckpoint(
            filepath=model_path,
            monitor="val_loss",
            save_best_only=True,
            verbose=1,
        ),
    ]

    # --- Train ---
    history = model.fit(
        X_train, y_train,
        validation_split=0.1,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks,
        verbose=1,
    )

    log.info("Training finished. Best model saved → %s", model_path)

    # --- Plot training curves ---
    _plot_training_curves(history, save_path=CURVES_PNG)
    log.info("Training curves saved → %s", CURVES_PNG)

    # --- Evaluate on test set ---
    y_prob = model.predict(X_test, batch_size=BATCH_SIZE).ravel()
    y_pred = (y_prob >= 0.5).astype(int)

    metrics = evaluate_model(
        y_test.astype(int), y_pred,
        y_prob=y_prob,
        model_name=display_name,
    )
    metrics["arch"] = arch

    # Save confusion matrix
    cm_path = os.path.join(MODELS_DIR, f"cm_{arch}.png")
    fig = plot_confusion_matrix(
        y_test.astype(int), y_pred,
        model_name=display_name,
        save_path=cm_path,
    )
    plt.close(fig)

    # Persist metrics
    with open(DL_METRICS_JSON, "w") as f:
        json.dump(metrics, f, indent=2)
    log.info("DL metrics saved → %s", DL_METRICS_JSON)

    return metrics


# ===========================================================================
# Plotting helper
# ===========================================================================

def _plot_training_curves(history, save_path: str) -> None:
    """Save accuracy & loss training curves from a Keras History object."""
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(13, 4))

    # --- Accuracy ---
    axes[0].plot(history.history["accuracy"], label="Train Accuracy", linewidth=2)
    axes[0].plot(history.history["val_accuracy"], label="Val Accuracy", linewidth=2, linestyle="--")
    axes[0].set_title("Accuracy over Epochs", fontsize=13, fontweight="bold")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].legend()
    axes[0].grid(alpha=0.4)

    # --- Loss ---
    axes[1].plot(history.history["loss"], label="Train Loss", linewidth=2)
    axes[1].plot(history.history["val_loss"], label="Val Loss", linewidth=2, linestyle="--")
    axes[1].set_title("Loss over Epochs", fontsize=13, fontweight="bold")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()
    axes[1].grid(alpha=0.4)

    fig.suptitle("Deep Learning Model — Training History", fontsize=14)
    fig.tight_layout()
    fig.savefig(save_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# ===========================================================================
# Public loader (used by predict.py & dashboard)
# ===========================================================================

def load_dl_model(arch: str = "lstm"):
    """
    Load a saved Keras model from disk.

    Parameters
    ----------
    arch : 'lstm' or 'ann'

    Returns
    -------
    Compiled tf.keras.Model
    """
    import tensorflow as tf

    arch = arch.lower()
    filename = "lstm_model.h5" if arch == "lstm" else "ann_model.h5"
    path = os.path.join(MODELS_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"DL model not found: {path}\n"
            "Run  python src/train_dl_model.py --arch {arch}  first."
        )
    return tf.keras.models.load_model(path)


def load_dl_metrics() -> dict:
    """Load saved DL metrics from JSON, or empty dict if not found."""
    if not os.path.exists(DL_METRICS_JSON):
        return {}
    with open(DL_METRICS_JSON) as f:
        return json.load(f)


# ===========================================================================
# Entry-point
# ===========================================================================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train DL fake-news classifier")
    parser.add_argument(
        "--arch",
        choices=["lstm", "ann"],
        default="lstm",
        help="Model architecture: 'lstm' (Bidirectional LSTM) or 'ann' (lightweight ANN). Default: lstm",
    )
    args = parser.parse_args()

    for path in [TRAIN_CLEAN, TEST_CLEAN]:
        if not os.path.exists(path):
            log.error("Missing %s — run  python src/preprocess.py  first.", path)
            sys.exit(1)

    metrics = train_dl_model(arch=args.arch)
    print(f"\n✅  DL training complete ({args.arch.upper()}).")
    print(json.dumps(metrics, indent=2))
