from __future__ import annotations
"""
train_ml_models.py
------------------
Train four classical ML classifiers on TF-IDF features:
  1. Logistic Regression
  2. Multinomial Naive Bayes
  3. Support Vector Machine  (LinearSVC)
  4. Random Forest

Each model is:
  - Fitted on the TF-IDF training matrix
  - Evaluated on the held-out test set
  - Saved to  models/<name>.pkl

A consolidated metrics JSON is written to  models/ml_metrics.json
so the Streamlit dashboard can load it without re-running inference.

Run:
    python src/train_ml_models.py
"""

import os
import sys
import json
import logging
import pickle

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV   # adds predict_proba to LinearSVC

# Local modules
sys.path.insert(0, os.path.dirname(__file__))
from features import (
    build_tfidf, transform_tfidf, save_tfidf,
    load_tfidf, TFIDF_PATH,
)
from evaluate import evaluate_model, plot_confusion_matrix, build_comparison_table

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
PROCESSED_DIR = os.path.join(PROJECT_ROOT, "data", "processed")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")

TRAIN_CLEAN = os.path.join(PROCESSED_DIR, "train_clean.csv")
TEST_CLEAN = os.path.join(PROCESSED_DIR, "test_clean.csv")
METRICS_JSON = os.path.join(MODELS_DIR, "ml_metrics.json")

logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model registry
# ---------------------------------------------------------------------------
def _get_model_definitions() -> dict:
    """
    Return a dict mapping a display name → (unfitted_estimator, filename).
    LinearSVC is wrapped with CalibratedClassifierCV to expose predict_proba.
    """
    return {
        "Logistic Regression": (
            LogisticRegression(
                max_iter=1000,
                solver="lbfgs",
                C=1.0,
                n_jobs=-1,
                random_state=42,
            ),
            "logistic_regression.pkl",
        ),
        "Naive Bayes": (
            MultinomialNB(alpha=0.1),
            "naive_bayes.pkl",
        ),
        "SVM": (
            CalibratedClassifierCV(
                LinearSVC(max_iter=2000, C=1.0, random_state=42),
                cv=3,
            ),
            "svm.pkl",
        ),
        "Random Forest": (
            RandomForestClassifier(
                n_estimators=200,
                max_depth=None,
                n_jobs=-1,
                random_state=42,
            ),
            "random_forest.pkl",
        ),
    }


# ---------------------------------------------------------------------------
# Core training loop
# ---------------------------------------------------------------------------

def train_all_models(
    X_train, y_train,
    X_test, y_test,
) -> list[dict]:
    """
    Train, evaluate and save all ML models.

    Parameters
    ----------
    X_train, X_test : Sparse TF-IDF matrices.
    y_train, y_test : Label arrays.

    Returns
    -------
    List of metric dicts (one per model), compatible with build_comparison_table().
    """
    os.makedirs(MODELS_DIR, exist_ok=True)
    definitions = _get_model_definitions()
    results = []

    for model_name, (estimator, filename) in definitions.items():
        log.info("Training  %s …", model_name)
        estimator.fit(X_train, y_train)

        y_pred = estimator.predict(X_test)

        # Probability for the positive class (Real = 1)
        if hasattr(estimator, "predict_proba"):
            y_prob = estimator.predict_proba(X_test)[:, 1]
        else:
            y_prob = None

        metrics = evaluate_model(
            y_test, y_pred, y_prob=y_prob, model_name=model_name
        )
        results.append(metrics)

        # Save confusion matrix PNG
        cm_path = os.path.join(MODELS_DIR, f"cm_{filename.replace('.pkl', '')}.png")
        fig = plot_confusion_matrix(y_test, y_pred, model_name=model_name, save_path=cm_path)
        import matplotlib.pyplot as plt
        plt.close(fig)

        # Persist model
        model_path = os.path.join(MODELS_DIR, filename)
        with open(model_path, "wb") as f:
            pickle.dump(estimator, f)
        log.info("Saved model → %s", model_path)

    return results


# ---------------------------------------------------------------------------
# Public helpers for dashboard
# ---------------------------------------------------------------------------

def load_model(model_name: str):
    """
    Load a saved ML model by its display name.

    Parameters
    ----------
    model_name : One of 'Logistic Regression', 'Naive Bayes', 'SVM',
                 'Random Forest'.

    Returns
    -------
    Fitted sklearn estimator.
    """
    name_to_file = {
        "Logistic Regression": "logistic_regression.pkl",
        "Naive Bayes": "naive_bayes.pkl",
        "SVM": "svm.pkl",
        "Random Forest": "random_forest.pkl",
    }
    filename = name_to_file.get(model_name)
    if filename is None:
        raise ValueError(
            f"Unknown model '{model_name}'. "
            f"Choose from: {list(name_to_file.keys())}"
        )
    path = os.path.join(MODELS_DIR, filename)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Model file not found: {path}\n"
            "Run  python src/train_ml_models.py  first."
        )
    with open(path, "rb") as f:
        return pickle.load(f)


def load_ml_metrics() -> pd.DataFrame:
    """
    Load the saved ML metrics JSON as a DataFrame.
    Returns an empty DataFrame if the file doesn't exist.
    """
    if not os.path.exists(METRICS_JSON):
        return pd.DataFrame()
    with open(METRICS_JSON) as f:
        return pd.DataFrame(json.load(f))


# ---------------------------------------------------------------------------
# Standalone entry-point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    # --- Guard: check required files ---
    for path in [TRAIN_CLEAN, TEST_CLEAN]:
        if not os.path.exists(path):
            log.error("Missing %s — run  python src/preprocess.py  first.", path)
            sys.exit(1)

    os.makedirs(MODELS_DIR, exist_ok=True)

    # --- Load data ---
    train_df = pd.read_csv(TRAIN_CLEAN)
    test_df = pd.read_csv(TEST_CLEAN)
    y_train = train_df["label"].values
    y_test = test_df["label"].values
    train_texts = train_df["clean_content"].fillna("").tolist()
    test_texts = test_df["clean_content"].fillna("").tolist()

    # --- Build / load TF-IDF ---
    if os.path.exists(TFIDF_PATH):
        log.info("Loading existing TF-IDF vectorizer …")
        tfidf = load_tfidf()
    else:
        tfidf = build_tfidf(train_texts)
        save_tfidf(tfidf)

    X_train = transform_tfidf(tfidf, train_texts)
    X_test = transform_tfidf(tfidf, test_texts)

    # --- Train ---
    results = train_all_models(X_train, y_train, X_test, y_test)

    # --- Save comparison table ---
    comparison_df = build_comparison_table(results)
    comparison_df.to_json(METRICS_JSON, orient="records", indent=2)
    log.info("Metrics saved → %s", METRICS_JSON)

    print("\n✅  ML training complete.")
    print(comparison_df.to_string(index=False))
